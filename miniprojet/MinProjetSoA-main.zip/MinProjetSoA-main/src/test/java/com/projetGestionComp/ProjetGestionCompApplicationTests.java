package com.projetGestionComp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetGestionCompApplicationTests {

	@Test
	void contextLoads() {
	}

}
