package com.projetGestionComp.Models;

public enum EtatPaiement {
    PAYEE,
    NON_PAYEE,
    INCONNU
}

