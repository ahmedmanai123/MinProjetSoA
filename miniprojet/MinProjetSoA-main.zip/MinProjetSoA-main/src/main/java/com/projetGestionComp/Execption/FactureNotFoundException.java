package com.projetGestionComp.Execption;

public class FactureNotFoundException extends Exception{
    public FactureNotFoundException(String message){}
}
