package com.projetGestionComp.Service;

public interface ClientService {

}
