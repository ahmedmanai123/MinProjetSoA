package com.projetGestionComp.Execption;

public class ClientNotFoundException extends Exception{
    public ClientNotFoundException (String message){}
}
